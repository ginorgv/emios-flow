'use strict'

/**
 * Pieza de EMIOS para EMIOS Flow (Activepieces).
 *
 * Permite consultar la plataforma EMIOS desde un flujo: redes, sensores,
 * valores actuales, historico por fechas y simulacion de factura.
 *
 * Los desplegables de red, sensor y tarifa se rellenan en vivo llamando al API
 * de EMIOS, para no tener que escribir identificadores a mano.
 */

const { createPiece, createAction, Property, PieceAuth } = require('@activepieces/pieces-framework')

const {
    BASE_POR_DEFECTO,
    llamarEmios,
    extraeLista,
    opcionesDeLista,
    dropdownConError,
} = require('./lib/emios-api')

const {
    ahoraEnMadrid,
    aMs,
    sumaDias,
    inicioDelDia,
    finDelDia,
    primerDiaDelMes,
    parteEnVentanas,
    formateaFechaEmios,
    parseaFechaEmios,
    extraePuntos,
    aprendeModelo,
    resumenPerfil,
    aplicaPrecio,
    marcaOrigenCoste,
    evaluaAnomalias,
    evaluaGasto,
    resumenAlarma,
    asuntoAlarma,
} = require('./lib/adaptativo')

const {
    agregaSensor,
    construyeRanking,
    resumenCadena,
    htmlResumenCadena,
    calculaCo2,
    empaquetaCo2,
    htmlHuellaCo2,
    FACTOR_CO2_POR_DEFECTO,
    comparaPeriodos,
    construyeDerivas,
    resumenDerivas,
    htmlResumenDerivas,
} = require('./lib/cadena')
const {
    descargaIntensidadHoraria,
    mapaDeIntensidad,
    co2Horario,
    mixMedio,
} = require('./lib/co2-ree')

const CLAVES_ETIQUETA_RED = ['nombre', 'nombre_red', 'descripcion', 'descripcion_red', 'red', 'clave', 'id_red']
const CLAVES_VALOR_RED = ['id_red', 'id', 'clave', 'red']
const CLAVES_ETIQUETA_SENSOR = ['nombre', 'nombre_sensor', 'descripcion', 'sensor', 'direccion', 'clave', 'id_sensor']
const CLAVES_VALOR_SENSOR = ['id_sensor', 'id', 'clave', 'sensor']
const CLAVES_ETIQUETA_TARIFA = ['nombre', 'nombre_tarifa', 'descripcion', 'tarifa', 'clave', 'id_tarifa']
const CLAVES_VALOR_TARIFA = ['id_tarifa', 'id', 'clave', 'tarifa']

// ----------------------------------------------------------------------------
// Conexion
// ----------------------------------------------------------------------------

const emiosAuth = PieceAuth.CustomAuth({
    displayName: 'Conexion EMIOS',
    required: true,
    description: 'Servidor de EMIOS y credenciales del API externo. Se recomienda crear un usuario de API dedicado por cliente.',
    props: {
        baseUrl: Property.ShortText({
            displayName: 'URL del servidor EMIOS',
            description: 'Sin barra final. Ejemplo: https://emios-v6-production.up.railway.app',
            required: true,
            defaultValue: BASE_POR_DEFECTO,
        }),
        usuario: Property.ShortText({
            displayName: 'Usuario del API',
            required: true,
        }),
        contrasenya: PieceAuth.SecretText({
            displayName: 'Contrasena del API',
            required: true,
        }),
    },
})

// ----------------------------------------------------------------------------
// Desplegables en vivo
// ----------------------------------------------------------------------------

const redDropdown = () => Property.Dropdown({
    displayName: 'Red',
    description: 'Red de EMIOS a la que pertenece el sensor',
    required: true,
    refreshers: [],
    options: async (propsValue) => {
        try {
            const json = await llamarEmios({
                auth: propsValue.auth,
                endpoint: 'dame_redes_usuario.php',
            })
            const lista = extraeLista(json, ['redes', 'lista_redes', 'dame_redes_usuario'])
            const opciones = opcionesDeLista(lista, CLAVES_ETIQUETA_RED, CLAVES_VALOR_RED)
            if (opciones.length === 0) {
                return dropdownConError('EMIOS no devolvio ninguna red para este usuario')
            }
            return { disabled: false, options: opciones }
        }
        catch (error) {
            return dropdownConError(`No se pudieron cargar las redes: ${error.message}`)
        }
    },
})

const sensorDropdown = () => Property.Dropdown({
    displayName: 'Sensor',
    description: 'Sensor de la red seleccionada',
    required: true,
    refreshers: ['id_red'],
    options: async (propsValue) => {
        const idRed = propsValue.id_red
        if (!idRed) {
            return dropdownConError('Elige primero la red')
        }
        try {
            const json = await llamarEmios({
                auth: propsValue.auth,
                endpoint: 'dame_sensores.php',
                parametros: { id_red: idRed },
            })
            const lista = extraeLista(json, ['sensores', 'lista_sensores', 'dame_sensores'])
            const opciones = opcionesDeLista(lista, CLAVES_ETIQUETA_SENSOR, CLAVES_VALOR_SENSOR)
            if (opciones.length === 0) {
                return dropdownConError('Esta red no tiene sensores')
            }
            return { disabled: false, options: opciones }
        }
        catch (error) {
            return dropdownConError(`No se pudieron cargar los sensores: ${error.message}`)
        }
    },
})

const tarifaDropdown = () => Property.Dropdown({
    displayName: 'Tarifa',
    description: 'Tarifa asociada al sensor',
    required: true,
    refreshers: ['id_red', 'id_sensor'],
    options: async (propsValue) => {
        const idRed = propsValue.id_red
        const idSensor = propsValue.id_sensor
        if (!idRed || !idSensor) {
            return dropdownConError('Elige primero la red y el sensor')
        }
        try {
            const json = await llamarEmios({
                auth: propsValue.auth,
                endpoint: 'dame_tarifa_sensor.php',
                parametros: { id_red: idRed, id_sensor: idSensor },
            })
            const lista = extraeLista(json, ['tarifas', 'lista_tarifas', 'dame_tarifa_sensor'])
            let opciones = opcionesDeLista(lista, CLAVES_ETIQUETA_TARIFA, CLAVES_VALOR_TARIFA)
            // EMIOS devuelve un unico objeto ('tarifa_sensor') cuando el sensor tiene tarifa asignada
            if (opciones.length === 0 && json.tarifa_sensor && typeof json.tarifa_sensor === 'object') {
                opciones = opcionesDeLista([json.tarifa_sensor], CLAVES_ETIQUETA_TARIFA, CLAVES_VALOR_TARIFA)
            }
            if (opciones.length === 0) {
                const sinTarifa = json.sensor_sin_tarifa === true || json.tarifa_sensor === null
                return dropdownConError(sinTarifa
                    ? 'Este sensor no tiene tarifa asignada en EMIOS'
                    : 'No se pudieron leer las tarifas de este sensor')
            }
            return { disabled: false, options: opciones }
        }
        catch (error) {
            return dropdownConError(`No se pudieron cargar las tarifas: ${error.message}`)
        }
    },
})

// ----------------------------------------------------------------------------
// Propiedades compartidas
// ----------------------------------------------------------------------------

const fechaHoraInicio = () => Property.ShortText({
    displayName: 'Fecha y hora de inicio',
    description: 'Formato de EMIOS: dd-mm-yyyy_HH:MM:SS  (ejemplo: 03-06-2024_00:00:00)',
    required: true,
})

const fechaHoraFin = () => Property.ShortText({
    displayName: 'Fecha y hora de fin',
    description: 'Formato de EMIOS: dd-mm-yyyy_HH:MM:SS  (ejemplo: 04-06-2024_23:00:00)',
    required: true,
})

const intervaloValores = () => Property.StaticDropdown({
    displayName: 'Intervalo de valores',
    description: 'Agrupacion de los valores devueltos. "tiempo_real" siempre esta disponible; el resto depende de la configuracion del sensor en EMIOS.',
    required: true,
    defaultValue: 'hora',
    options: {
        options: [
            { label: 'Tiempo real', value: 'tiempo_real' },
            { label: 'Cada hora', value: 'hora' },
            { label: 'Cada dia', value: 'dia' },
            { label: 'Cada semana', value: 'semana' },
            { label: 'Cada mes', value: 'mes' },
            { label: 'Cada cuarto de hora', value: 'cuartohora' },
        ],
    },
})

// ----------------------------------------------------------------------------
// Acciones
// ----------------------------------------------------------------------------

const listarRedes = createAction({
    name: 'listar_redes',
    displayName: 'Listar redes',
    description: 'Devuelve las redes de EMIOS a las que tiene acceso el usuario del API',
    props: {},
    run: async (context) => {
        const json = await llamarEmios({ auth: context.auth, endpoint: 'dame_redes_usuario.php' })
        return {
            ...json,
            lista_redes: extraeLista(json, ['redes', 'lista_redes', 'dame_redes_usuario']),
        }
    },
})

const listarSensores = createAction({
    name: 'listar_sensores',
    displayName: 'Listar sensores',
    description: 'Devuelve los sensores de una red de EMIOS',
    props: {
        id_red: redDropdown(),
    },
    run: async (context) => {
        const json = await llamarEmios({
            auth: context.auth,
            endpoint: 'dame_sensores.php',
            parametros: { id_red: context.propsValue.id_red },
        })
        return {
            ...json,
            lista_sensores: extraeLista(json, ['sensores', 'lista_sensores', 'dame_sensores']),
        }
    },
})

const valoresActuales = createAction({
    name: 'valores_actuales',
    displayName: 'Valores actuales de un sensor',
    description: 'Ultimo valor disponible del sensor (tiempo real e intervalos procesados)',
    props: {
        id_red: redDropdown(),
        id_sensor: sensorDropdown(),
    },
    run: async (context) => {
        return llamarEmios({
            auth: context.auth,
            endpoint: 'dame_valores_actuales_sensor.php',
            parametros: {
                id_red: context.propsValue.id_red,
                id_sensor: context.propsValue.id_sensor,
            },
        })
    },
})

const historicoValores = createAction({
    name: 'historico_valores',
    displayName: 'Historico de valores',
    description: 'Valores del sensor entre dos fechas. Limites de EMIOS: 31 dias por consulta (366 en algunos intervalos) y 50.000 valores',
    props: {
        id_red: redDropdown(),
        id_sensor: sensorDropdown(),
        fecha_hora_inicio: fechaHoraInicio(),
        fecha_hora_fin: fechaHoraFin(),
        intervalo_valores: intervaloValores(),
    },
    run: async (context) => {
        return llamarEmios({
            auth: context.auth,
            endpoint: 'dame_valores_rango_fechas_sensor.php',
            parametros: {
                id_red: context.propsValue.id_red,
                id_sensor: context.propsValue.id_sensor,
                fecha_hora_inicio: context.propsValue.fecha_hora_inicio,
                fecha_hora_fin: context.propsValue.fecha_hora_fin,
                intervalo_valores: context.propsValue.intervalo_valores,
            },
        })
    },
})

const simularFactura = createAction({
    name: 'simular_factura',
    displayName: 'Simular factura',
    description: 'Simula la factura del sensor con una tarifa de EMIOS',
    props: {
        id_red: redDropdown(),
        id_sensor: sensorDropdown(),
        id_tarifa: tarifaDropdown(),
        fecha_hora_inicio: fechaHoraInicio(),
        fecha_hora_fin: fechaHoraFin(),
    },
    run: async (context) => {
        return llamarEmios({
            auth: context.auth,
            endpoint: 'dame_simulacion_factura_sensor_tarifa.php',
            parametros: {
                id_red: context.propsValue.id_red,
                id_sensor: context.propsValue.id_sensor,
                id_tarifa: context.propsValue.id_tarifa,
                fecha_hora_inicio: context.propsValue.fecha_hora_inicio,
                fecha_hora_fin: context.propsValue.fecha_hora_fin,
            },
        })
    },
})

// ----------------------------------------------------------------------------
// Alarmas adaptativas ("vivas") y alertas de gasto
// ----------------------------------------------------------------------------

const metricaDropdown = () => Property.StaticDropdown({
    displayName: 'Magnitud a vigilar',
    description: 'Que se analiza en cada franja horaria.',
    required: true,
    defaultValue: 'consumo',
    options: {
        options: [
            { label: 'Consumo', value: 'consumo' },
            { label: 'Gasto en euros (coste)', value: 'coste' },
            { label: 'Incremento', value: 'incremento' },
        ],
    },
})

/** Lee el historial del sensor en trozos (el API no admite mas de 31 dias por consulta). */
async function leeHistorial({ auth, idRed, idSensor, desde, hasta, intervalo, metrica }) {
    const ventanas = parteEnVentanas(desde, hasta, 31)
    const puntos = []
    let descartados = 0
    const tramos = []

    for (const ventana of ventanas) {
        const json = await llamarEmios({
            auth,
            endpoint: 'dame_valores_rango_fechas_sensor.php',
            parametros: {
                id_red: idRed,
                id_sensor: idSensor,
                fecha_hora_inicio: ventana.desde,
                fecha_hora_fin: ventana.hasta,
                intervalo_valores: intervalo,
            },
        })
        const extraido = extraePuntos(json, metrica)
        puntos.push(...extraido.puntos)
        descartados += extraido.descartados
        tramos.push({ desde: ventana.desde, hasta: ventana.hasta, lecturas: extraido.puntos.length })

        // El API de EMIOS permite 60 consultas por minuto: margen entre tramos.
        if (ventanas.length > 1) {
            await new Promise((resolver) => setTimeout(resolver, 250))
        }
    }

    puntos.sort((a, b) => a.ms - b.ms)
    return { puntos, descartados, tramos, ventanas: ventanas.length }
}

/** Acepta el modelo como objeto o como texto JSON (para encadenar pasos). */
function normalizaModelo(valor) {
    if (!valor) {
        throw new Error('Falta el perfil aprendido: usa la salida "modelo" del paso "Aprender el perfil"')
    }
    if (typeof valor === 'string') {
        return JSON.parse(valor)
    }
    return valor
}

/** Nombre del sensor, solo para los textos (si falla, no rompe la accion). */
async function nombreDelSensor({ auth, idRed, idSensor }) {
    try {
        const json = await llamarEmios({ auth, endpoint: 'dame_sensores.php', parametros: { id_red: idRed } })
        const lista = extraeLista(json, ['sensores', 'lista_sensores', 'dame_sensores'])
        const encontrado = lista.find((sensor) => String(sensor.id_sensor ?? sensor.id ?? sensor.clave) === String(idSensor))
        return encontrado ? (encontrado.nombre || encontrado.nombre_sensor || null) : null
    }
    catch (error) {
        return null
    }
}

const aprenderPerfil = createAction({
    name: 'aprender_perfil',
    displayName: 'Aprender el perfil del sensor (alarma viva)',
    description: 'Analiza el historial y construye el perfil normal del sensor por franja horaria (dia de la semana + hora). Ese perfil es lo que hace que la alarma se adapte sola a cada epoca del ano, sin reprogramar nada. Recomendado: ejecutarlo una vez al dia o a la semana.',
    props: {
        id_red: redDropdown(),
        id_sensor: sensorDropdown(),
        metrica: metricaDropdown(),
        dias_historial: Property.Number({
            displayName: 'Dias de historial',
            description: 'Con 30 dias ya aprende el perfil semanal; con 365 aprende ademas la estacionalidad del ano. Se ignora si rellenas las fechas de abajo.',
            required: true,
            defaultValue: 30,
        }),
        fecha_hora_inicio: Property.ShortText({
            displayName: 'Fecha y hora de inicio (opcional)',
            description: 'Formato dd-mm-yyyy_HH:MM:SS. Si la rellenas junto con la fecha de fin, se analiza ese periodo en vez de los ultimos dias.',
            required: false,
        }),
        fecha_hora_fin: Property.ShortText({
            displayName: 'Fecha y hora de fin (opcional)',
            description: 'Formato dd-mm-yyyy_HH:MM:SS.',
            required: false,
        }),
        precio_energia: Property.Number({
            displayName: 'Precio por unidad (opcional)',
            description: 'Por ejemplo EUR/kWh. Si las lecturas de EMIOS no traen coste, se calcula coste = valor x precio para poder avisar en dinero.',
            required: false,
        }),
        intervalo_valores: intervaloValores(),
    },
    run: async (context) => {
        const idRed = context.propsValue.id_red
        const idSensor = context.propsValue.id_sensor
        const metrica = context.propsValue.metrica
        const dias = Math.max(1, Math.min(400, Number(context.propsValue.dias_historial) || 30))
        const ahora = ahoraEnMadrid()
        const inicioExplicito = parseaFechaEmios(context.propsValue.fecha_hora_inicio)
        const finExplicito = parseaFechaEmios(context.propsValue.fecha_hora_fin)
        const usaFechas = Boolean(inicioExplicito && finExplicito)
        const hasta = usaFechas ? finExplicito : finDelDia(ahora)
        const desde = usaFechas ? inicioExplicito : inicioDelDia(sumaDias(ahora, -dias))

        const { puntos, descartados, tramos } = await leeHistorial({
            auth: context.auth,
            idRed,
            idSensor,
            desde,
            hasta,
            intervalo: context.propsValue.intervalo_valores || 'hora',
            metrica,
        })

        if (puntos.length === 0) {
            throw new Error(`EMIOS no devolvio lecturas para el sensor ${idSensor} en el periodo indicado. Revisa las fechas, el intervalo de valores ('${context.propsValue.intervalo_valores || 'hora'}') y que el sensor tenga datos.`)
        }

        const precio = context.propsValue.precio_energia
        const puntosConPrecio = aplicaPrecio(puntos, precio)
        const modelo = marcaOrigenCoste(aprendeModelo(puntosConPrecio, metrica), precio)
        const nombre = await nombreDelSensor({ auth: context.auth, idRed, idSensor })

        return {
            ok: true,
            id_red: idRed,
            id_sensor: idSensor,
            nombre_sensor: nombre,
            metrica,
            lecturas: puntos.length,
            descartados,
            tramos,
            precio_energia_aplicado: modelo.precio_energia,
            modelo,
            modelo_json: JSON.stringify(modelo),
            resumen: resumenPerfil(modelo, { idRed, idSensor, nombreSensor: nombre }),
        }
    },
})

const comprobarAlarma = createAction({
    name: 'comprobar_alarma',
    displayName: 'Comprobar alarma adaptativa y gasto',
    description: 'Compara las ultimas lecturas con el perfil aprendido y con el presupuesto del cliente. Devuelve si hay que avisar, las desviaciones detectadas, el gasto de hoy y la proyeccion de fin de mes.',
    props: {
        id_red: redDropdown(),
        id_sensor: sensorDropdown(),
        metrica: metricaDropdown(),
        modelo: Property.Json({
            displayName: 'Perfil aprendido',
            description: 'Salida "modelo" del paso "Aprender el perfil".',
            required: true,
        }),
        horas_a_revisar: Property.Number({
            displayName: 'Horas a revisar',
            description: 'Cuantas horas atras se comparan con el perfil. Se ignora si rellenas las fechas de abajo.',
            required: true,
            defaultValue: 24,
        }),
        fecha_hora_inicio: Property.ShortText({
            displayName: 'Fecha y hora de inicio a revisar (opcional)',
            description: 'Formato dd-mm-yyyy_HH:MM:SS. Con la fecha de fin, revisa ese periodo concreto.',
            required: false,
        }),
        fecha_hora_fin: Property.ShortText({
            displayName: 'Fecha y hora de fin a revisar (opcional)',
            description: 'Formato dd-mm-yyyy_HH:MM:SS.',
            required: false,
        }),
        presupuesto_mes: Property.Number({
            displayName: 'Presupuesto mensual (EUR)',
            description: 'Opcional. Si se indica, avisa cuando el mes vaya camino de superarlo.',
            required: false,
        }),
        umbral_sigma: Property.Number({
            displayName: 'Sensibilidad (desviaciones tipicas)',
            description: 'Por defecto 3. Bajalo a 2 para avisos mas sensibles.',
            required: true,
            defaultValue: 3,
        }),
        minimo_muestras: Property.Number({
            displayName: 'Minimo de muestras por franja',
            description: 'Si una franja tiene menos muestras, se compara con el perfil por hora del dia.',
            required: true,
            defaultValue: 3,
        }),
        precio_energia: Property.Number({
            displayName: 'Precio por unidad (opcional)',
            description: 'Por ejemplo EUR/kWh. Si las lecturas no traen coste, se calcula coste = valor x precio (debe coincidir con el empleado al aprender el perfil).',
            required: false,
        }),
        avisar_a: Property.ShortText({
            displayName: 'Avisar a (opcional)',
            description: 'Correos separados por comas. Se devuelven en "destinatarios_aviso" solo si hay alarma o se supera el presupuesto, para que el paso de correo no envie nada cuando no toca.',
            required: false,
        }),
        intervalo_valores: intervaloValores(),
    },
    run: async (context) => {
        const idRed = context.propsValue.id_red
        const idSensor = context.propsValue.id_sensor
        const metrica = context.propsValue.metrica
        const modelo = normalizaModelo(context.propsValue.modelo)
        const horas = Math.max(1, Math.min(400, Number(context.propsValue.horas_a_revisar) || 24))
        const ahora = ahoraEnMadrid()
        const intervalo = context.propsValue.intervalo_valores || 'hora'
        const inicioExplicito = parseaFechaEmios(context.propsValue.fecha_hora_inicio)
        const finExplicito = parseaFechaEmios(context.propsValue.fecha_hora_fin)
        const usaFechas = Boolean(inicioExplicito && finExplicito)
        const desde = usaFechas ? inicioExplicito : inicioDelDia(sumaDias(ahora, -Math.ceil(horas / 24)))
        const hasta = usaFechas ? finExplicito : finDelDia(ahora)
        const { puntos: puntosBrutos } = await leeHistorial({
            auth: context.auth,
            idRed,
            idSensor,
            desde,
            hasta,
            intervalo,
            metrica,
        })
        const precio = context.propsValue.precio_energia
        const puntos = aplicaPrecio(puntosBrutos, precio)

        const evaluacion = evaluaAnomalias({
            puntos,
            modelo,
            umbralSigma: Number(context.propsValue.umbral_sigma) || 3,
            minimoMuestras: Number(context.propsValue.minimo_muestras) || 3,
        })

        // Gasto acumulado del mes de la fecha de referencia, para proyectar a fin de mes.
        const referencia = hasta
        const { puntos: puntosMes } = await leeHistorial({
            auth: context.auth,
            idRed,
            idSensor,
            desde: primerDiaDelMes(referencia),
            hasta: referencia,
            intervalo,
            metrica,
        })
        const costeMes = aplicaPrecio(puntosMes, precio).reduce((suma, punto) => suma + (punto.coste || 0), 0)

        const gasto = evaluaGasto({
            puntos,
            modelo,
            costeMesAcumulado: costeMes,
            ahora: referencia,
            presupuestoMes: context.propsValue.presupuesto_mes,
        })
        gasto.origen_coste = modelo.origen_coste === 'calculado' ? 'calculado' : 'emios'
        gasto.precio_energia = modelo.precio_energia

        const hayAnomalia = evaluacion.anomalias.length > 0
        const superaPresupuesto = Boolean(gasto.presupuesto && gasto.presupuesto.supera_presupuesto)
        const debeAvisar = hayAnomalia || superaPresupuesto
        const nombre = await nombreDelSensor({ auth: context.auth, idRed, idSensor })

        // Solo se devuelven destinatarios si hay algo que contar: es lo que usa el
        // paso de correo para no enviar nada cuando todo esta normal.
        const avisar = String(context.propsValue.avisar_a || '')
            .split(/[,;\s]+/)
            .map((correo) => correo.trim())
            .filter((correo) => correo.includes('@'))

        return {
            hay_alarma: debeAvisar,
            debe_avisar: debeAvisar,
            destinatarios_aviso: debeAvisar ? avisar : [],
            hay_anomalia: hayAnomalia,
            supera_presupuesto: superaPresupuesto,
            gravedad: hayAnomalia ? evaluacion.anomalias[0].gravedad : 'baja',
            total_anomalias: evaluacion.anomalias.length,
            anomalias: evaluacion.anomalias.slice(0, 10),
            lecturas_revisadas: puntos.length,
            sin_referencia: evaluacion.sin_referencia,
            id_red: idRed,
            id_sensor: idSensor,
            nombre_sensor: nombre,
            metrica,
            gasto,
            resumen: resumenAlarma({
                anomalias: evaluacion,
                gasto,
                modelo,
                nombreSensor: nombre,
                idRed,
                idSensor,
                metrica,
            }),
            asunto: asuntoAlarma({ anomalias: evaluacion, gasto, nombreSensor: nombre, idSensor, metrica }),
        }
    },
})

const consultarEmios = createAction({
    name: 'consultar_emios',
    displayName: 'Consulta avanzada al API de EMIOS',
    description: 'Llama a cualquier endpoint del API externo de EMIOS y devuelve el JSON tal cual. Util para endpoints que todavia no tienen accion propia.',
    props: {
        endpoint: Property.ShortText({
            displayName: 'Endpoint',
            description: 'Ejemplo: dame_valores_actuales_sensor.php',
            required: true,
        }),
        parametros: Property.Json({
            displayName: 'Parametros adicionales',
            description: 'Objeto JSON con los parametros del endpoint (no incluyas usuario ni contrasena: van en la conexion).',
            required: false,
        }),
    },
    run: async (context) => {
        const parametros = typeof context.propsValue.parametros === 'string'
            ? JSON.parse(context.propsValue.parametros || '{}')
            : (context.propsValue.parametros || {})
        return llamarEmios({
            auth: context.auth,
            endpoint: String(context.propsValue.endpoint).trim(),
            parametros,
        })
    },
})

const rankingCadena = createAction({
    name: 'ranking_cadena',
    displayName: 'Informe de ahorro de la cadena (en euros)',
    description: 'Recorre los contadores de energia de una red y devuelve el gasto en EUR de cada uno, el precio real pagado (EUR/kWh), el peso de la madrugada y la oportunidad de ahorro. Pensado para el informe semanal de una cadena.',
    props: {
        id_red: redDropdown(),
        filtro_nombre: Property.ShortText({
            displayName: 'Filtrar contadores por nombre (opcional)',
            description: 'Ejemplo: "Contador] Activa" para quedarte solo con los contadores principales de cada edificio. Vacio = todos los de energia activa.',
            required: false,
        }),
        dias: Property.Number({
            displayName: 'Dias a analizar',
            description: 'Ventana hacia atras desde hoy: 7 (semana), 30 (mes) o 90 (trimestre). Cada 31 dias es una consulta extra por contador.',
            required: true,
            defaultValue: 7,
        }),
        max_sensores: Property.Number({
            displayName: 'Maximo de contadores a consultar',
            description: 'El API de EMIOS permite 60 consultas por minuto: cada contador es una consulta.',
            required: true,
            defaultValue: 40,
        }),
        top: Property.Number({
            displayName: 'Cuantos contadores en el ranking',
            required: true,
            defaultValue: 10,
        }),
        precio_energia: Property.Number({
            displayName: 'Precio por unidad si falta coste (opcional)',
            required: false,
        }),
        avisar_a: Property.ShortText({
            displayName: 'Enviar el informe a (opcional)',
            description: 'Correos separados por comas. Se devuelven en "destinatarios_aviso" solo si hay datos: asi el flujo semanal nunca envia un informe vacio.',
            required: false,
        }),
        factor_co2: Property.Number({
            displayName: 'Factor de emision de CO2 de respaldo (kg CO2/kWh)',
            description: `Solo se usa si no hay token de ESIOS o si REE no responde. 0,20 es prudente para el mix espanol (oscila entre 0,05 y 0,25 segun la hora y el ano). Vacio = ${FACTOR_CO2_POR_DEFECTO}.`,
            required: false,
            defaultValue: FACTOR_CO2_POR_DEFECTO,
        }),
        token_esios: Property.ShortText({
            displayName: 'Token de ESIOS para CO2 real (opcional)',
            description: 'Token personal gratuito de ree.es. Con el, la huella se calcula cruzando el consumo horario real con el mix de generacion real de cada hora (dato oficial de Red Electrica). Si falla, el informe sale igualmente con el factor de respaldo.',
            required: false,
        }),
        intervalo_valores: intervaloValores(),
    },
    run: async (context) => {
        const idRed = context.propsValue.id_red
        // Hasta 92 dias: cubre el trimestre del informe ESG. El API se consulta en tramos de 31 dias.
        const dias = Math.max(1, Math.min(92, Number(context.propsValue.dias) || 7))
        const maxSensores = Math.max(1, Math.min(60, Number(context.propsValue.max_sensores) || 40))
        const top = Math.max(1, Math.min(50, Number(context.propsValue.top) || 10))
        const filtro = String(context.propsValue.filtro_nombre || '').trim().toLowerCase()

        // 1) nombre de la red (para los textos)
        let nombreRed = `red ${idRed}`
        try {
            const redes = await llamarEmios({ auth: context.auth, endpoint: 'dame_redes_usuario.php' })
            const listaRedes = extraeLista(redes, ['redes', 'lista_redes', 'dame_redes_usuario'])
            const encontrada = listaRedes.find((red) => String(red.id_red ?? red.id ?? red.clave) === String(idRed))
            if (encontrada) {
                nombreRed = encontrada.nombre || encontrada.nombre_red || nombreRed
            }
        }
        catch (error) { /* el nombre es cosmetico */ }

        // 2) contadores de energia activa de la red
        const jsonSensores = await llamarEmios({
            auth: context.auth,
            endpoint: 'dame_sensores.php',
            parametros: { id_red: idRed },
        })
        const sensores = extraeLista(jsonSensores, ['sensores', 'lista_sensores', 'dame_sensores'])
        const candidatos = sensores
            .filter((sensor) => String(sensor.clase || '').toUpperCase().includes('ENERGIA_ACTIVA'))
            .filter((sensor) => !filtro || String(sensor.nombre || '').toLowerCase().includes(filtro))
            .slice(0, maxSensores)

        if (candidatos.length === 0) {
            throw new Error(`No hay contadores de energia activa en la red ${idRed}${filtro ? ` que contengan "${filtro}"` : ''}.`)
        }

        // 3) lecturas de cada contador
        const ahora = ahoraEnMadrid()
        const desde = inicioDelDia(sumaDias(ahora, -dias))
        const hasta = finDelDia(ahora)
        const filas = []
        const puntosPorSensor = []
        let sinDatos = 0

        for (const sensor of candidatos) {
            const idSensor = sensor.id_sensor ?? sensor.id ?? sensor.clave
            try {
                const { puntos } = await leeHistorial({
                    auth: context.auth,
                    idRed,
                    idSensor,
                    desde,
                    hasta,
                    intervalo: context.propsValue.intervalo_valores || 'hora',
                    metrica: 'incremento',
                })
                if (puntos.length === 0) {
                    sinDatos++
                    continue
                }
                filas.push(agregaSensor({ nombre: sensor.nombre || String(idSensor), puntos, precioEnergia: context.propsValue.precio_energia }))
                // Se guardan las lecturas para poder cruzar el CO2 hora a hora con REE
                puntosPorSensor.push({ nombre: sensor.nombre || String(idSensor), puntos })
            }
            catch (error) {
                sinDatos++
            }
            // margen para respetar las 60 consultas/minuto de EMIOS
            await new Promise((resolver) => setTimeout(resolver, 250))
        }

        const ranking = construyeRanking({ filas, top, dias })
        // Huella de carbono: con token de ESIOS se calcula hora a hora con el mix
        // real de Red Electrica; si no, se aplica el factor de respaldo.
        let co2 = null
        let avisoCo2 = null
        const tokenEsios = String(context.propsValue.token_esios || '').trim()
        if (tokenEsios && puntosPorSensor.length > 0) {
            try {
                const descarga = await descargaIntensidadHoraria({ token: tokenEsios, desde: aMs(desde), hasta: aMs(hasta) })
                const mapa = mapaDeIntensidad(descarga)
                let kg = 0
                let kwhCubiertos = 0
                let kwhSinDato = 0
                for (const sensor of puntosPorSensor) {
                    const calculo = co2Horario({ puntos: sensor.puntos, intensidadPorHora: mapa })
                    kg += calculo.kg
                    kwhCubiertos += calculo.kwh_cubiertos
                    kwhSinDato += calculo.kwh_sin_dato
                }
                if (kg > 0 && kwhCubiertos > 0) {
                    co2 = empaquetaCo2({
                        kg,
                        kwh: kwhCubiertos,
                        factorKgKwh: kg / kwhCubiertos,
                        fuente: descarga.fuente,
                        extra: {
                            horas: descarga.horas,
                            descargado: descarga.descargado,
                            kwh_sin_dato: Math.round(kwhSinDato * 10) / 10,
                            mix_medio: mixMedio(descarga),
                        },
                    })
                }
                else {
                    avisoCo2 = 'REE devolvio mix horario pero sin cruzar con el consumo; se usa el factor de respaldo.'
                }
            }
            catch (error) {
                avisoCo2 = `No se pudo calcular el CO2 con REE (${error.message}); se usa el factor de respaldo.`
            }
        }
        if (!co2) {
            co2 = calculaCo2({ kwh: ranking.total_kwh, factor: context.propsValue.factor_co2 })
        }
        const resumen = resumenCadena({ ranking, nombreRed, periodo: `ultimos ${dias} dias`, co2 })
        const htmlResumen = htmlResumenCadena({ ranking, nombreRed, periodo: `ultimos ${dias} dias`, co2 })

        const avisar = String(context.propsValue.avisar_a || '')
            .split(/[,;\s]+/)
            .map((correo) => correo.trim())
            .filter((correo) => correo.includes('@'))
        const hayDatos = ranking.sensores_analizados > 0

        return {
            ok: hayDatos,
            debe_avisar: hayDatos,
            destinatarios_aviso: hayDatos ? avisar : [],
            red: nombreRed,
            id_red: idRed,
            dias,
            consultados: candidatos.length,
            sin_datos: sinDatos,
            gasto_total_eur: ranking.total_eur,
            precio_medio_eur_kwh: ranking.eur_kwh_medio,
            oportunidad_mes_eur: ranking.oportunidad_mes,
            co2_kg: co2.kg,
            co2_toneladas: co2.toneladas,
            co2_fuente: co2.fuente,
            co2_intensidad_g_kwh: Math.round(co2.factor_kg_kwh * 1000 * 10) / 10,
            aviso_co2: avisoCo2,
            co2,
            ranking,
            resumen,
            html_resumen: htmlResumen,
        }
    },
})

// ----------------------------------------------------------------------------
// Derivas: mantenimiento predictivo (que contador se esta desmadrando)
// ----------------------------------------------------------------------------

const derivas = createAction({
    name: 'derivas',
    displayName: 'Derivas de consumo (mantenimiento predictivo)',
    description: 'Compara los ultimos N dias con los N anteriores de CADA contador de la red, a igualdad de condiciones (mismo intervalo, misma tarifa). Devuelve los que empeoran con su desvio en % y el dinero en riesgo por mes: el aviso llega antes de la averia.',
    props: {
        id_red: redDropdown(),
        filtro_nombre: Property.ShortText({
            displayName: 'Filtrar contadores por nombre (opcional)',
            description: 'Ejemplo: "Contador] Activa" para quedarte solo con los contadores principales de cada edificio. Vacio = todos los de energia activa.',
            required: false,
        }),
        dias: Property.Number({
            displayName: 'Dias por periodo',
            description: 'Se comparan N dias contra los N anteriores. Para el aviso semanal, 7 (necesita 14 dias de historico).',
            required: true,
            defaultValue: 7,
        }),
        umbral_porcentaje: Property.Number({
            displayName: 'Umbral de aviso (%)',
            description: 'Cuanto tiene que subir el consumo para considerarlo deriva. Por debajo de 10-15% hay ruido de estacionalidad.',
            required: true,
            defaultValue: 15,
        }),
        max_sensores: Property.Number({
            displayName: 'Maximo de contadores a consultar',
            description: 'El API de EMIOS permite 60 consultas por minuto y 720 por hora: cada contador es 1 consulta (2 si el periodo supera 31 dias).',
            required: true,
            defaultValue: 20,
        }),
        top: Property.Number({
            displayName: 'Cuantos contadores por tabla',
            required: true,
            defaultValue: 10,
        }),
        precio_energia: Property.Number({
            displayName: 'Precio por unidad si falta coste (opcional)',
            required: false,
        }),
        avisar_a: Property.ShortText({
            displayName: 'Enviar el aviso a (opcional)',
            description: 'Correos separados por comas. Solo se devuelven en "destinatarios_aviso" si hay alguna deriva: el flujo nunca avisa de que no pasa nada.',
            required: false,
        }),
        intervalo_valores: intervaloValores(),
    },
    run: async (context) => {
        const idRed = context.propsValue.id_red
        const dias = Math.max(1, Math.min(31, Number(context.propsValue.dias) || 7))
        const umbral = Math.abs(Number(context.propsValue.umbral_porcentaje) || 15)
        const maxSensores = Math.max(1, Math.min(60, Number(context.propsValue.max_sensores) || 20))
        const top = Math.max(1, Math.min(50, Number(context.propsValue.top) || 10))
        const filtro = String(context.propsValue.filtro_nombre || '').trim().toLowerCase()

        // 1) nombre de la red (cosmetico)
        let nombreRed = `red ${idRed}`
        try {
            const redes = await llamarEmios({ auth: context.auth, endpoint: 'dame_redes_usuario.php' })
            const listaRedes = extraeLista(redes, ['redes', 'lista_redes', 'dame_redes_usuario'])
            const encontrada = listaRedes.find((red) => String(red.id_red ?? red.id ?? red.clave) === String(idRed))
            if (encontrada) {
                nombreRed = encontrada.nombre || encontrada.nombre_red || nombreRed
            }
        }
        catch (error) { /* el nombre es cosmetico */ }

        // 2) contadores de energia activa
        const jsonSensores = await llamarEmios({
            auth: context.auth,
            endpoint: 'dame_sensores.php',
            parametros: { id_red: idRed },
        })
        const sensores = extraeLista(jsonSensores, ['sensores', 'lista_sensores', 'dame_sensores'])
        const candidatos = sensores
            .filter((sensor) => String(sensor.clase || '').toUpperCase().includes('ENERGIA_ACTIVA'))
            .filter((sensor) => !filtro || String(sensor.nombre || '').toLowerCase().includes(filtro))
            .slice(0, maxSensores)

        if (candidatos.length === 0) {
            throw new Error(`No hay contadores de energia activa en la red ${idRed}${filtro ? ` que contengan "${filtro}"` : ''}.`)
        }

        // 3) una sola consulta por contador que cubre los DOS periodos
        const ahora = ahoraEnMadrid()
        const hasta = finDelDia(ahora)
        const corte = inicioDelDia(sumaDias(ahora, -(dias - 1))) // inicio del periodo actual
        const desde = inicioDelDia(sumaDias(ahora, -(2 * dias - 1)))
        const filas = []
        let sinDatos = 0

        for (const sensor of candidatos) {
            const idSensor = sensor.id_sensor ?? sensor.id ?? sensor.clave
            try {
                const { puntos } = await leeHistorial({
                    auth: context.auth,
                    idRed,
                    idSensor,
                    desde,
                    hasta,
                    intervalo: context.propsValue.intervalo_valores || 'hora',
                    metrica: 'incremento',
                })
                if (puntos.length === 0) {
                    sinDatos++
                    continue
                }
                filas.push({
                    nombre: sensor.nombre || String(idSensor),
                    comparacion: comparaPeriodos({
                        puntos,
                        corteMs: aMs(corte),
                        precioEnergia: context.propsValue.precio_energia,
                    }),
                })
            }
            catch (error) {
                sinDatos++
            }
            // margen para respetar las 60 consultas/minuto de EMIOS
            await new Promise((resolver) => setTimeout(resolver, 250))
        }

        const resultado = construyeDerivas({ filas, umbralPorcentaje: umbral, dias, top })
        const periodo = `${dias} dias vs ${dias} anteriores`
        const resumen = resumenDerivas({ derivas: resultado, nombreRed, periodo })
        const htmlResumen = htmlResumenDerivas({ derivas: resultado, nombreRed, periodo })

        const avisar = String(context.propsValue.avisar_a || '')
            .split(/[,;\s]+/)
            .map((correo) => correo.trim())
            .filter((correo) => correo.includes('@'))
        const hayDeriva = resultado.total_empeoran > 0

        return {
            ok: hayDeriva,
            debe_avisar: hayDeriva,
            destinatarios_aviso: hayDeriva ? avisar : [],
            red: nombreRed,
            id_red: idRed,
            dias,
            umbral_porcentaje: resultado.umbral_porcentaje,
            consultados: candidatos.length,
            sin_datos: sinDatos,
            sensores_analizados: resultado.sensores_analizados,
            total_empeoran: resultado.total_empeoran,
            total_mejoran: resultado.total_mejoran,
            estables: resultado.estables,
            en_riesgo_eur: resultado.total_empeoran_eur,
            en_riesgo_mes_eur: resultado.total_empeoran_mes_eur,
            ahorro_mes_eur: resultado.total_ahorro_mes_eur,
            derivas: resultado,
            empeoran: resultado.empeoran,
            mejoran: resultado.mejoran,
            resumen,
            html_resumen: htmlResumen,
        }
    },
})

// ----------------------------------------------------------------------------
// Huella de CO2 detallada (scope 2): por contador, por hora y exportable
// ----------------------------------------------------------------------------

/** Numero con coma decimal, para que Excel en espanol lo lea como numero. */
function numeroEspanol(valor, decimales = 2) {
    const numero = Number(valor)
    if (!Number.isFinite(numero)) {
        return ''
    }
    return numero.toFixed(decimales).replace('.', ',')
}

const huellaCo2 = createAction({
    name: 'huella_co2',
    displayName: 'Huella de CO2 detallada (scope 2, por contador y por hora)',
    description: 'Calcula la huella de la electricidad cruzando el consumo horario real de cada contador con la intensidad de CO2 de esa misma hora (mix de Red Electrica). Devuelve reparto por contador, evolucion mensual, mix de la red, nota metodologica lista para auditoria y el detalle horario en CSV.',
    props: {
        id_red: redDropdown(),
        filtro_nombre: Property.ShortText({
            displayName: 'Filtrar contadores por nombre (opcional)',
            description: 'Ejemplo: "Contador] Activa" para quedarte solo con los contadores principales de cada edificio.',
            required: false,
        }),
        dias: Property.Number({
            displayName: 'Dias a analizar',
            description: 'Ventana hacia atras desde hoy: 31 (mes), 92 (trimestre) o 365 (ano, ojo: son 12 tramos de consulta por contador).',
            required: true,
            defaultValue: 31,
        }),
        max_sensores: Property.Number({
            displayName: 'Maximo de contadores',
            description: 'Cada contador es 1 consulta por tramo de 31 dias. El API de EMIOS permite 60/minuto y 720/hora.',
            required: true,
            defaultValue: 15,
        }),
        token_esios: Property.ShortText({
            displayName: 'Token de ESIOS (recomendado)',
            description: 'Token personal gratuito de ree.es. Sin el, la huella se calcula con un factor fijo y el informe no sirve para auditoria.',
            required: false,
        }),
        factor_co2: Property.Number({
            displayName: 'Factor de respaldo (kg CO2/kWh)',
            description: 'Solo se usa si falta el token o si REE no responde.',
            required: false,
            defaultValue: FACTOR_CO2_POR_DEFECTO,
        }),
        avisar_a: Property.ShortText({
            displayName: 'Enviar el informe a (opcional)',
            description: 'Correos separados por comas.',
            required: false,
        }),
        intervalo_valores: intervaloValores(),
    },
    run: async (context) => {
        const idRed = context.propsValue.id_red
        const dias = Math.max(1, Math.min(366, Number(context.propsValue.dias) || 31))
        const maxSensores = Math.max(1, Math.min(40, Number(context.propsValue.max_sensores) || 15))
        const filtro = String(context.propsValue.filtro_nombre || '').trim().toLowerCase()

        let nombreRed = `red ${idRed}`
        try {
            const redes = await llamarEmios({ auth: context.auth, endpoint: 'dame_redes_usuario.php' })
            const listaRedes = extraeLista(redes, ['redes', 'lista_redes', 'dame_redes_usuario'])
            const encontrada = listaRedes.find((red) => String(red.id_red ?? red.id ?? red.clave) === String(idRed))
            if (encontrada) {
                nombreRed = encontrada.nombre || encontrada.nombre_red || nombreRed
            }
        }
        catch (error) { /* cosmetico */ }

        const jsonSensores = await llamarEmios({
            auth: context.auth,
            endpoint: 'dame_sensores.php',
            parametros: { id_red: idRed },
        })
        const sensores = extraeLista(jsonSensores, ['sensores', 'lista_sensores', 'dame_sensores'])
        const candidatos = sensores
            .filter((sensor) => String(sensor.clase || '').toUpperCase().includes('ENERGIA_ACTIVA'))
            .filter((sensor) => !filtro || String(sensor.nombre || '').toLowerCase().includes(filtro))
            .slice(0, maxSensores)

        if (candidatos.length === 0) {
            throw new Error(`No hay contadores de energia activa en la red ${idRed}${filtro ? ` que contengan "${filtro}"` : ''}.`)
        }

        const ahora = ahoraEnMadrid()
        const desde = inicioDelDia(sumaDias(ahora, -(dias - 1)))
        const hasta = finDelDia(ahora)

        const lecturas = []
        let sinDatos = 0
        for (const sensor of candidatos) {
            const idSensor = sensor.id_sensor ?? sensor.id ?? sensor.clave
            try {
                const { puntos } = await leeHistorial({
                    auth: context.auth,
                    idRed,
                    idSensor,
                    desde,
                    hasta,
                    intervalo: context.propsValue.intervalo_valores || 'hora',
                    metrica: 'incremento',
                })
                if (puntos.length === 0) {
                    sinDatos++
                    continue
                }
                lecturas.push({ nombre: sensor.nombre || String(idSensor), puntos })
            }
            catch (error) {
                sinDatos++
            }
            await new Promise((resolver) => setTimeout(resolver, 250))
        }

        // Intensidad horaria oficial de REE
        let descarga = null
        let avisoCo2 = null
        const tokenEsios = String(context.propsValue.token_esios || '').trim()
        if (tokenEsios) {
            try {
                descarga = await descargaIntensidadHoraria({ token: tokenEsios, desde: aMs(desde), hasta: aMs(hasta) })
            }
            catch (error) {
                avisoCo2 = `No se pudo usar el mix de REE (${error.message}); se usa el factor de respaldo.`
            }
        }
        else {
            avisoCo2 = 'Sin token de ESIOS: la huella se calcula con un factor fijo, no vale para auditoria.'
        }

        const mapa = descarga ? mapaDeIntensidad(descarga) : null
        const factorRespaldo = Number(context.propsValue.factor_co2) > 0 ? Number(context.propsValue.factor_co2) : FACTOR_CO2_POR_DEFECTO

        const contadores = []
        const meses = new Map()
        const filasCsv = []
        let kgTotal = 0
        let kwhTotal = 0
        let kwhCubiertos = 0

        for (const lectura of lecturas) {
            let kg = 0
            let kwh = 0
            let kwhSinDato = 0

            for (const punto of lectura.puntos) {
                const consumo = Number(punto.valor) || 0
                if (!(consumo > 0)) {
                    continue
                }
                const intensidad = mapa ? intensidadDeHora(mapa, punto.ms) : null
                const gKwh = intensidad === null ? (mapa ? null : factorRespaldo * 1000) : intensidad
                const kgFila = gKwh === null ? 0 : (consumo * gKwh) / 1000

                kwh += consumo
                if (gKwh === null) {
                    kwhSinDato += consumo
                }
                else {
                    kg += kgFila
                    kwhCubiertos += consumo
                }

                const fecha = punto.fecha || {}
                const claveMes = `${fecha.y}-${String(fecha.mo).padStart(2, '0')}`
                const acumuladoMes = meses.get(claveMes) || { mes: claveMes, kwh: 0, kg: 0 }
                acumuladoMes.kwh += consumo
                acumuladoMes.kg += kgFila
                meses.set(claveMes, acumuladoMes)

                filasCsv.push([
                    lectura.nombre,
                    `${String(fecha.d).padStart(2, '0')}-${String(fecha.mo).padStart(2, '0')}-${fecha.y}`,
                    `${String(fecha.h).padStart(2, '0')}:${String(fecha.mi || 0).padStart(2, '0')}`,
                    numeroEspanol(consumo, 3),
                    gKwh === null ? '' : numeroEspanol(gKwh, 1),
                    gKwh === null ? '' : numeroEspanol(kgFila, 3),
                ])
            }

            kgTotal += kg
            kwhTotal += kwh
            contadores.push({
                nombre: lectura.nombre,
                kwh: Math.round(kwh * 10) / 10,
                kg: Math.round(kg * 10) / 10,
                intensidad_g_kwh: kwh - kwhSinDato > 0 ? Math.round((kg / (kwh - kwhSinDato)) * 1000 * 10) / 10 : null,
                kwh_sin_dato: Math.round(kwhSinDato * 10) / 10,
            })
        }

        contadores.sort((a, b) => b.kg - a.kg)

        const co2 = empaquetaCo2({
            kg: kgTotal,
            kwh: kwhCubiertos,
            factorKgKwh: kwhCubiertos > 0 ? kgTotal / kwhCubiertos : factorRespaldo,
            fuente: descarga ? descarga.fuente : 'factor fijo configurable',
            extra: descarga
                ? { horas: descarga.horas, descargado: descarga.descargado }
                : {},
        })

        const huella = {
            co2,
            kwh_total: Math.round(kwhTotal * 10) / 10,
            cobertura_porcentaje: kwhTotal > 0 ? Math.round((kwhCubiertos / kwhTotal) * 1000) / 10 : 0,
            horas: descarga ? descarga.horas : 0,
            contadores,
            meses: [...meses.values()]
                .map((fila) => ({
                    mes: fila.mes,
                    kwh: Math.round(fila.kwh * 10) / 10,
                    kg: Math.round(fila.kg * 10) / 10,
                    intensidad_g_kwh: fila.kwh > 0 ? Math.round((fila.kg / fila.kwh) * 1000 * 10) / 10 : null,
                }))
                .sort((a, b) => a.mes.localeCompare(b.mes)),
            mix: descarga ? mixMedio(descarga, 8) : [],
        }

        const cabeceraCsv = 'contador;fecha;hora;kwh;g_co2_kwh;kg_co2'
        const csv = [cabeceraCsv, ...filasCsv.map((fila) => fila.join(';'))].join('\n')

        const periodo = `ultimos ${dias} dias`
        const lineas = []
        lineas.push(`HUELLA DE CO2 · ${nombreRed} · ${periodo}`)
        lineas.push('')
        lineas.push(`Emisiones: ${formateaNumero(co2.kg, 0)} kg CO2 (${formateaNumero(co2.toneladas, 2)} t) sobre ${formateaNumero(huella.kwh_total, 0)} kWh.`)
        lineas.push(`Intensidad media: ${formateaNumero(co2.factor_kg_kwh * 1000, 0)} g CO2/kWh (${co2.fuente}).`)
        lineas.push(`Cobertura del dato horario: ${formateaNumero(huella.cobertura_porcentaje, 1)}% · ${huella.contadores.length} contadores.`)
        lineas.push('')
        lineas.push('REPARTO POR CONTADOR')
        huella.contadores.slice(0, 8).forEach((fila, indice) => {
            lineas.push(`${indice + 1}. ${fila.nombre}: ${formateaNumero(fila.kg, 0)} kg (${formateaNumero(fila.kwh, 0)} kWh · ${formateaNumero(fila.intensidad_g_kwh, 0)} g/kWh)`)
        })
        if (avisoCo2) {
            lineas.push('')
            lineas.push(`AVISO: ${avisoCo2}`)
        }

        const avisar = String(context.propsValue.avisar_a || '')
            .split(/[,;\s]+/)
            .map((correo) => correo.trim())
            .filter((correo) => correo.includes('@'))
        const hayDatos = huella.contadores.length > 0

        return {
            ok: hayDatos,
            debe_avisar: hayDatos,
            destinatarios_aviso: hayDatos ? avisar : [],
            red: nombreRed,
            id_red: idRed,
            dias,
            consultados: candidatos.length,
            sin_datos: sinDatos,
            kwh_total: huella.kwh_total,
            co2_kg: co2.kg,
            co2_toneladas: co2.toneladas,
            co2_intensidad_g_kwh: Math.round(co2.factor_kg_kwh * 1000 * 10) / 10,
            co2_fuente: co2.fuente,
            cobertura_porcentaje: huella.cobertura_porcentaje,
            aviso_co2: avisoCo2,
            co2,
            contadores,
            meses: huella.meses,
            mix: huella.mix,
            horas_ree: huella.horas,
            filas_csv: filasCsv.length,
            csv,
            resumen: lineas.join('\n'),
            html_resumen: htmlHuellaCo2({ huella, nombreRed, periodo }),
        }
    },
})

// ----------------------------------------------------------------------------
// Pieza
// ----------------------------------------------------------------------------

const emios = createPiece({
    displayName: 'EMIOS',
    description: 'Plataforma EMIOS de gestion energetica: redes, sensores, valores y simulacion de factura',
    logoUrl: 'https://app-production-e0fdb.up.railway.app/brand/emios-icon.svg',
    authors: ['Energy Minus'],
    auth: emiosAuth,
    // Categorias del catalogo: "Energia" no existe, asi que se agrupa donde la buscaria
    // un cliente de EMIOS (analisis de datos y facturacion).
    categories: ['BUSINESS_INTELLIGENCE', 'ACCOUNTING'],
    minimumSupportedRelease: '0.0.0',
    actions: [
        listarRedes,
        listarSensores,
        valoresActuales,
        historicoValores,
        simularFactura,
        aprenderPerfil,
        comprobarAlarma,
        consultarEmios,
        rankingCadena,
        derivas,
        huellaCo2,
    ],
    triggers: [],
})

module.exports = {
    emios,
}
